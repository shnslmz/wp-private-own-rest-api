=== Private Own REST API ===
Tags: api, private rest, your own api
Requires at least: 4.9
Tested up to: 6.0
Requires PHP: +7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This plugin shows JSONplaceHolder's (API) users list and their detail info on a DataTable, a private WP virtual page and/or existing page/post using Wordpress shortcode.
 => The default API URL for user listing: https://jsonplaceholder.typicode.com/users
 => The default API URL for user listing: https://jsonplaceholder.typicode.com/users/{id}/posts