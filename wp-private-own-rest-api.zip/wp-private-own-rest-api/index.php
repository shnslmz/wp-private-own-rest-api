<?php 

// You know what they say: Silence is golden..